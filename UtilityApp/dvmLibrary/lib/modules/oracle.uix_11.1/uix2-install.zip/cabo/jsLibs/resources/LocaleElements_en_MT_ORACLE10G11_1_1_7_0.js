var LocaleSymbols_en_MT = new LocaleSymbols({
DateTimeElements:["1", "4"], 
MonthAbbreviations:["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 
DayNames:["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"], 
NumberElements:[".", ",", ";", "%", "0", "#", "-", "E", "\u2030", "\u221e", "NaN"], 
DateTimePatterns:["HH:mm:ss z", "HH:mm:ss z", "HH:mm:ss", "HH:mm", "EEEE, d MMMM yyyy", "dd MMMM yyyy", "dd MMM yyyy", "dd/MM/yyyy", "{1} {0}"], 
Eras:["BC", "AD"], 
AmPmMarkers:["AM", "PM"], 
DayAbbreviations:["sun", "mon", "tue", "wed", "thu", "fri", "sat"], 
MonthNames:["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"]
});
