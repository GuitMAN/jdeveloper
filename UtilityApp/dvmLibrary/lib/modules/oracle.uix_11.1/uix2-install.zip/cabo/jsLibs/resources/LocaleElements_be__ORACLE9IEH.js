var LocaleSymbols_be = new LocaleSymbols({
DateTimeElements:["1", "1"], 
MonthAbbreviations:["Muharram", "Safar", "Rabi\x27 Awwal", "Rabi\x27 Thani", "Jamada El Oula", "Jamada El Thani", "Rajab", "Sha\x27Ban", "Ramadan", "Shawwal", "Thoul Ki\x27Dah", "Thoul Hijjah"], 
DayNames:["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], 
NumberElements:[",", "\xa0", ";", "%", "0", "#", "-", "E", "\u2030", "\u221e", "\ufffd"], 
DateTimePatterns:["H.mm.ss z", "H.mm.ss z", "H.mm.ss", "H.mm", "EEEE, d, MMMM yyyy", "EEEE, d, MMMM yyyy", "d.M.yyyy", "d.M.yy", "{1} {0}"], 
Eras:["bh", ""], 
AmPmMarkers:["AM", "PM"], 
DayAbbreviations:["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], 
MonthNames:["Muharram", "Safar", "Rabi\x27 Awwal", "Rabi\x27 Thani", "Jamada El Oula", "Jamada El Thaniah", "Rajab", "Sha\x27Ban", "Ramadan", "Shawwal", "Thoul Ki\x27Dah", "Thoul Hijjah"]
});
