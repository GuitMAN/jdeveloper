var LocaleSymbols_bg_BG = new LocaleSymbols({
DateTimeElements:["1", "1"], 
MonthAbbreviations:["Muharram", "Safar", "Rabi\x27 Awwal", "Rabi\x27 Thani", "Jamada El Oula", "Jamada El Thani", "Rajab", "Sha\x27Ban", "Ramadan", "Shawwal", "Thoul Ki\x27Dah", "Thoul Hijjah"], 
DayNames:["\u041d\u0435\u0434\u0435\u043b\u044f", "\u041f\u043e\u043d\u0435\u0434\u0435\u043b\u043d\u0438\u043a", "\u0412\u0442\u043e\u0440\u043d\u0438\u043a", "\u0421\u0440\u044f\u0434\u0430", "\u0427\u0435\u0442\u0432\u044a\u0440\u0442\u044a\u043a", "\u041f\u0435\u0442\u044a\u043a", "\u0421\u044a\u0431\u043e\u0442\u0430"], 
NumberElements:[",", "\xa0", ";", "%", "0", "#", "-", "E", "\u2030", "\u221e", "\ufffd"], 
DateTimePatterns:["HH:mm:ss z", "HH:mm:ss z", "H:mm:ss", "H:mm", "EEEE, yyyy, MMMM d", "EEEE, yyyy, MMMM d", "yyyy-M-d", "yy-M-d", "{1} {0}"], 
Eras:["bh", ""], 
AmPmMarkers:["AM", "PM"], 
DayAbbreviations:["\u041d\u0434", "\u041f\u043d", "\u0412\u0442", "\u0421\u0440", "\u0427\u0442", "\u041f\u0442", "\u0421\u0431"], 
MonthNames:["Muharram", "Safar", "Rabi\x27 Awwal", "Rabi\x27 Thani", "Jamada El Oula", "Jamada El Thaniah", "Rajab", "Sha\x27Ban", "Ramadan", "Shawwal", "Thoul Ki\x27Dah", "Thoul Hijjah"]
});
